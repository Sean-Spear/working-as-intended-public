WORKING AS INTENDED — Windows version
=====================================

Double-click WorkingAsIntended.exe. That's it: the game opens in its own window.
No browser, no install, nothing to download.

First launch
------------
Windows may show "Windows protected your PC" because this little program isn't
code-signed. Click "More info", then "Run anyway". It only asks once.

Saves
-----
Your progress is kept in  %LOCALAPPDATA%\WorkingAsIntended
(separate from any copy you played in a web browser, so this starts a new save).
To start over, use "Forget everything" on the title screen.

Requirements
------------
Windows 10 or 11 (64-bit). The game uses the Microsoft Edge WebView2 runtime,
which ships with Windows 10 and 11. If it's ever missing, the game will say so
and point you to Microsoft's free installer.

Controls
--------
Move: Arrows / WASD      Jump: C / Space / K      Dash: X / Left Shift / J
Read / use: Up / Z / E    Map & journal: Tab / M   Pause: Esc / P
Gamepads work too. Every key and button can be changed under
Pause > Controls (or Controls on the title screen).
Maximise the window (or drag its edges) to make it bigger.
